package com.cts;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Seller implements Serializable {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int seller_id; 
	private String username;
	private String password;
	private String companyname;
	private float gstin;
	private String brief;
	private String postal_address;
	private String website;
	private String email;
	private int contact;
	public int getId() {
		return seller_id;
	}
	public void setId(int id) {
		this.seller_id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public float getGstin() {
		return gstin;
	}
	public void setGstin(float gstin) {
		this.gstin = gstin;
	}
	public String getBrief() {
		return brief;
	}
	public void setBrief(String brief) {
		this.brief = brief;
	}
	public String getPostal_address() {
		return postal_address;
	}
	public void setPostal_address(String postal_address) {
		this.postal_address = postal_address;
	}
	public String getWebsite() {
		return website;
	}
	public void setWebsite(String website) {
		this.website = website;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getContact() {
		return contact;
	}
	public void setContact(int contact) {
		this.contact = contact;
	}
	public Seller(int seller_id, String username, String password, String companyname, float gstin, String brief,
			String postal_address, String website, String email, int contact) {
		super();
		this.seller_id = seller_id;
		this.username = username;
		this.password = password;
		this.companyname = companyname;
		this.gstin = gstin;
		this.brief = brief;
		this.postal_address = postal_address;
		this.website = website;
		this.email = email;
		this.contact = contact;
	}
	public Seller() {
		
	}
	
	


}

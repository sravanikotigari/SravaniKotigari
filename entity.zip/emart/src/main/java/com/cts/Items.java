package com.cts;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity
public class Items implements Serializable {
	
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int item_id;
	@ManyToOne
	private Category category_id;
	@OneToOne
	private Subcategory subcategory_id;
	private float price;
	private String item_name;
	private String description;
	private int stock_number;
	private String remarks;
	public int getItem_id() {
		return item_id;
	}
	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}
	public float getPrice() {
		return price;
	}
	public void setPrice(float price) {
		this.price = price;
	}
	public String getItem_name() {
		return item_name;
	}
	public void setItem_name(String item_name) {
		this.item_name = item_name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getStock_number() {
		return stock_number;
	}
	public void setStock_number(int stock_number) {
		this.stock_number = stock_number;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Items(int item_id, float price, String item_name, String description, int stock_number, String remarks) {
		super();
		this.item_id = item_id;
		this.price = price;
		this.item_name = item_name;
		this.description = description;
		this.stock_number = stock_number;
		this.remarks = remarks;
	}
	public Items() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
	

}

package com.cts;

import java.io.Serializable;
import java.time.LocalDate;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;

@Entity

public class Purchasehistory implements Serializable {
	
	@Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	
	@ManyToOne
	@JoinColumn(name="buyer_id")
	private Buyer buyer_id;
	
	private int seller_id;
	
	private int transaction_id;
	
	private int item_id;
	
	private int number_of_items;
	
	private LocalDate date;
	
	private String remarks;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	
	public int getSeller_id() {
		return seller_id;
	}
	public void setSeller_id(int seller_id) {
		this.seller_id = seller_id;
	}
	public void setDate(LocalDate date) {
		this.date = date;
	}
	public int getTransaction_id() {
		return transaction_id;
	}
	public void setTransaction_id(int transaction_id) {
		this.transaction_id = transaction_id;
	}
	public int getItem_id() {
		return item_id;
	}
	public void setItem_id(int item_id) {
		this.item_id = item_id;
	}
	public int getNumber_of_items() {
		return number_of_items;
	}
	public void setNumber_of_items(int number_of_items) {
		this.number_of_items = number_of_items;
	}
	public LocalDate getDate() {
		return date;
	}
	public void setDate_time(LocalDate date) {
		this.date = date;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public Purchasehistory(int id,  int seller_id, int transaction_id, int item_id, int number_of_items,
			LocalDate date, String remarks) {
		super();
		this.id = id;
		
		this.seller_id = seller_id;
		this.transaction_id = transaction_id;
		this.item_id = item_id;
		this.number_of_items = number_of_items;
		this.date = date;
		this.remarks = remarks;
	}
	public Purchasehistory() {
	// TODO Auto-generated constructor stub
	}
	
	


}

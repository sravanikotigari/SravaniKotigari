package com.cts.repository;

public class Interfaceservice {

}
